/**
 * errors.js — vistas globales 403/404/500 (CP-05). Script clásico: expone `tm.ui.errors`.
 */
(function (global) {
  "use strict";

  const { el, clear, pageHeader } = global.tm.layout;

  function panel(kind, title, hint) {
    const card = el("div", "card app-error-state");
    card.appendChild(pageHeader(title, hint));

    const p = el("p", "app-error-state__message");
    p.textContent =
      kind === "forbidden"
        ? "Esta ruta existe pero tu rol no tiene permiso para entrar."
        : kind === "not-found"
          ? "La ruta no existe en el inventario de pantallas."
          : "El sistema no pudo procesar la solicitud en este momento.";
    card.appendChild(p);

    const btn = el("button", "btn btn--primary");
    btn.type = "button";
    btn.textContent = kind === "forbidden" ? "Ir a mi inicio" : "Volver al inicio";
    btn.addEventListener("click", () => {
      const go = (route) => {
        window.history.pushState({}, "", global.tm.router.toPath(route));
        window.dispatchEvent(new PopStateEvent("popstate"));
      };
      if (kind === "forbidden") {
        const role = global.tm.session.getSession()?.datos.rol;
        go(global.tm.roles.INITIAL_ROUTE[role] ?? "#/mis-tramites");
      } else {
        go(global.tm.session.isAuthenticated() ? "#/mis-tramites" : "#/login");
      }
    });
    card.appendChild(btn);
    return card;
  }

  function renderForbidden(container) {
    clear(container);
    container.appendChild(panel("forbidden", "403 — Sin acceso", "Permiso denegado"));
  }

  function renderNotFound(container) {
    clear(container);
    container.appendChild(panel("not-found", "404 — Página no encontrada", "Ruta desconocida"));
  }

  function renderServerError(container) {
    clear(container);
    container.appendChild(panel("server", "500 — Error interno", "Algo salió mal"));
  }

  global.tm.ui = global.tm.ui || {};
  global.tm.ui.errors = { renderForbidden, renderNotFound, renderServerError };
})(window);
