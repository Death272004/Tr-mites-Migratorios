# Ley 81 de 26 de marzo de 2019 sobre Protección de Datos Personales

*Gaceta Oficial Digital N.° 28743-A, viernes 29 de marzo de 2019*

**LA ASAMBLEA NACIONAL**

**DECRETA:**

## Capítulo I — Disposiciones Generales

### Artículo 1.

Esta Ley tiene por objeto establecer los principios, derechos, obligaciones y procedimientos que regulan la protección de datos personales, considerando su interrelación con la vida privada y demás derechos y libertades fundamentales de los ciudadanos, por parte de las personas naturales o jurídicas, de derecho público o privado, lucrativas o no, que traten datos personales en los términos previstos en esta Ley.

Toda persona, natural o jurídica, de derecho público o privado, lucrativa o no, puede efectuar el tratamiento de datos personales, siempre que lo haga con arreglo a la presente Ley y para los fines permitidos en el ordenamiento jurídico. En todo caso, deberá respetar el pleno ejercicio de los derechos fundamentales de los titulares de los datos y de las facultades que esta Ley les reconoce.

### Artículo 2.

Los principios generales en los cuales se inspiran y rigen la protección de datos de carácter personal, en cuanto a la interpretación y aplicación de la normativa, son:

1. Principio de lealtad: los datos personales deberán recabarse sin engaño o falsedad y sin utilizar medios fraudulentos, desleales o ilícitos.

2. Principio de finalidad: los datos personales deben ser recolectados con fines determinados y no ser tratados posteriormente para fines incompatibles o distintos para los cuales se solicitaron, ni conservarse por tiempo mayor del necesario para los fines de tratamiento.

3. Principio de proporcionalidad: solo deberán ser solicitados aquellos datos adecuados, pertinentes y limitados al mínimo necesario en relación con la finalidad para la que son requeridos.

4. Principio de veracidad y exactitud: los datos de carácter personal serán exactos y puestos al día de manera que respondan con veracidad a la situación actual del propietario del dato.

5. Principio de seguridad de los datos: los responsables del tratamiento de los datos personales deberán adoptar las medidas de índole técnica y organizativa necesarias para garantizar la seguridad de los datos bajo su custodia, principalmente cuando se trate de datos considerados sensibles, e informar al titular, lo más pronto posible, cuando los datos hayan sido sustraídos sin autorización o haya indicios suficientes de que su seguridad ha sido vulnerada.

6. Principio de transparencia: toda información o comunicación al titular de los datos personales relativa al tratamiento de estos deberá ser en lenguaje sencillo y claro, y mantenerlo informado de todos los derechos que le amparan como titular del dato, así como la posibilidad de ejercer los derechos ARCO.

7. Principio de confidencialidad: todas las personas que intervengan en el tratamiento de datos personales están obligadas a guardar secreto o confidencialidad respecto de estos, incluso cuando hayan finalizado su relación con el titular o responsable del tratamiento de datos, impidiendo el acceso o uso no autorizado.

8. Principio de licitud: para que el tratamiento de un dato personal sea lícito, deberá ser recolectado y tratado con el consentimiento previo, informado e inequívoco del titular del dato o por fundamento legal.

9. Principio de portabilidad: el titular de los datos tiene derecho a obtener de parte del responsable del tratamiento una copia de los datos personales de manera estructurada en un formato genérico y de uso común.

### Artículo 3.

Se exceptúan del ámbito de esta Ley aquellos tratamientos que expresamente se encuentren regulados por leyes especiales o por las normativas que las desarrollen, además de los tratamientos de datos personales siguientes:

1. Los que realice una persona natural para actividades exclusivamente personales o domésticas.

2. Los que realicen autoridades competentes con fines de prevención, investigación, detección o enjuiciamiento de infracciones penales o de ejecución de sanciones penales.

3. Los que se efectúen para el análisis de inteligencia financiera y relativos a la seguridad nacional de conformidad con las legislaciones, tratados o convenios internacionales que regulen estas materias.

4. Cuando se trate de tratamiento de datos relacionados con organismos internacionales, en cumplimiento de lo dispuesto en los tratados y convenios vigentes ratificados por la República de Panamá.

5. Los resultantes de información obtenida mediante un procedimiento previo de disociación o anonimización, de manera que el resultado no pueda asociarse al titular de los datos personales.

### Artículo 4.

Para los efectos de esta Ley, los términos siguientes se entenderán así:

1. Almacenamiento de datos. Conservación o custodia de datos en una base de datos establecida en cualquier medio provisto, incluido el de las Tecnologías de la Información y la Comunicación (TICs).

2. Base de datos. Conjunto ordenado de datos de cualquier naturaleza, cualquiera que sea la forma o modalidad de su creación, organización o almacenamiento, que permite relacionar los datos entre sí, así como realizar cualquier tipo de tratamiento o transmisión de estos por parte de su custodio.

3. Bloqueo de datos. Restricción temporal de cualquier acceso o tratamiento de los datos almacenados.

4. Consentimiento. Manifestación de la voluntad del titular de los datos, mediante la cual se efectúa el tratamiento de estos.

5. Custodio de la base de datos. Persona natural o jurídica, de derecho público o privado, lucrativa o no, que actúa a nombre y por cuenta del responsable del tratamiento y le compete la custodia y conservación de la base de datos.

6. Datos confidenciales. Aquellos datos que por su naturaleza no deben ser de conocimiento público o de terceros no autorizados, incluyendo aquellos que estén protegidos por ley, por acuerdos de confidencialidad o no divulgación, a fin de salvaguardar información. En los casos de la Administración Pública, son aquellos datos cuyo tratamiento está limitado para fines de esta Administración o si se cuenta con el consentimiento expreso del titular, sin perjuicio de lo dispuesto por leyes especiales o por las normativas que las desarrollen. Los datos confidenciales siempre serán de acceso restringido.

7. Dato anónimo. Aquel dato cuya identidad no puede ser establecida por medios razonables o el nexo entre este y la persona natural a la que se refiere.

8. Dato caduco. Aquel dato que ha perdido actualidad por disposición de la ley, por el cumplimiento de la condición o la expiración del plazo señalado para su vigencia o, si no hubiera norma expresa, por el cambio de los hechos o circunstancias que consigna.

9. Dato personal. Cualquier información concerniente a personas naturales, que las identifica o las hace identificables.

10. Dato disociado. Aquel dato que no puede asociarse al titular ni permitir por su estructura, contenido o grado de desagregación la identificación de la persona, sea esta natural.

11. Dato sensible. Aquel que se refiera a la esfera íntima de su titular, o cuya utilización indebida pueda dar origen a discriminación o conlleve un riesgo grave para este. De manera enunciativa, se consideran sensibles los datos personales que puedan revelar aspectos como origen racial o étnico; creencias o convicciones religiosas, filosóficas y morales; afiliación sindical; opiniones políticas; datos relativos a la salud, a la vida, a la preferencia u orientación sexual, datos genéticos o datos biométricos, entre otros, sujetos a regulación y dirigidos a identificar de manera unívoca a una persona natural.

12. Eliminación o cancelación de datos. Suprimir o borrar de forma permanente los datos almacenados en bases de datos, cualquiera que sea el procedimiento empleado para ello.

13. Ficha técnica. Documento que contiene los registros, protocolos y reglas, relacionados al almacenamiento y tratamiento de los datos personales.

14. Fuente accesible. Bases de datos que no sean de acceso restringido o contengan reserva alguna a consultas, o que sean de acceso público, como las publicaciones estatales de carácter oficial, los medios de comunicación, los directorios telefónicos y la lista de personas que pertenecen a un grupo de profesionales que contengan únicamente nombre, título o profesión, actividad, dirección laboral o comercial, al igual que información que indique su pertenencia a organismos.

15. Modificación de datos. Todo cambio en el contenido de los datos almacenados en bases de datos.

16. Procedimiento de disociación o anonimización. Todo tratamiento de datos que impide que la información disponible en la base de datos pueda asociarse a persona natural determinada o determinable.

17. Responsable del tratamiento de los datos. Persona natural o jurídica, de derecho público o privado, lucrativa o no, que le corresponde las decisiones relacionadas con el tratamiento de los datos y que determina los fines, medios y alcance, así como cuestiones relacionadas a estos.

18. Titular de los datos. Persona natural a la que se refieren los datos.

19. Transferencia de datos. Dar a conocer, divulgar, comunicar, intercambiar y/o transmitir, de cualquier forma y por cualquier medio, de un punto a otro, intra o extrafronterizo, los datos a personas naturales o jurídicas distintas del titular, ya sean determinadas o indeterminadas.

20. Tratamiento de datos. Cualquier operación o complejo de operaciones o procedimientos técnicos, de carácter automatizado o no, que permita recolectar, almacenar, grabar, organizar, elaborar, seleccionar, extraer, confrontar, interconectar, asociar, disociar, comunicar, ceder, intercambiar, transferir, transmitir o cancelar datos, o utilizarlos en cualquier otra forma.

### Artículo 5.

Las bases de datos que se encuentren en el territorio de la República de Panamá, que almacenen o contengan datos personales de nacionales o extranjeros o que el responsable del tratamiento de los datos esté domiciliado en el país quedan sujetas a las normas establecidas en esta Ley o su reglamentación.

Se excluye de esta normativa la base de datos de sujetos regulados por leyes especiales, siempre que estas leyes que lo regulan o su normativa que las desarrollan establezcan estándares técnicos mínimos necesarios para la correcta protección y tratamiento de datos personales, conforme a lo establecido en esta Ley.

El almacenamiento o transferencia de datos personales originados o almacenados dentro de la República de Panamá que sean confidenciales, sensibles o restringidos, que reciban un tratamiento transfronterizo, será permitido siempre que el responsable del almacenamiento de esos datos o el custodio de estos cumpla con los estándares de protección de datos personales exigidos por esta Ley, o pueda demostrar que cumple con los estándares y normas de protección de datos personales iguales o superiores a los exigidos por la presente Ley.

Se exceptúan para efectos del requerimiento que trata el párrafo anterior, los casos siguientes:

1. Cuando el titular haya otorgado su consentimiento para la transferencia.

2. Cuando la transferencia sea necesaria para la celebración o ejecución de un contrato celebrado o por celebrar por el interesado o en interés de este.

3. Cuando se trate de transferencias bancarias, dinerarias y bursátiles del mercado de valores.

4. Cuando se trate de información cuya transmisión sea requerida por ello en cumplimiento de tratados internacionales ratificados por la República de Panamá.

En cualquiera de los casos, el tratamiento o transferencia de datos personales que se realice a través de Internet o cualquier otro medio de comunicación electrónica, digital o física, el custodio de la base de datos y/o el responsable por el tratamiento deberá cumplir con los estándares, normas, certificaciones, protocolos, medidas técnicas y de gestión informática adecuados para preservar la seguridad en sus sistemas o redes, o en la prestación de sus servicios, con el fin de garantizar los niveles de protección de los datos personales tal cual lo establece esta Ley y su reglamentación, así como las certificaciones, protocolos, estándares y otras medidas que se establezcan.

### Artículo 6.

El tratamiento de datos personales solo podrá realizarse cuando se cumplan al menos una de las condiciones siguientes:

1. Que se obtenga el consentimiento del titular de los datos.

2. Que el tratamiento de los datos sea necesario para la ejecución de una obligación contractual, siempre que el titular de los datos sea parte.

3. Que el tratamiento sea necesario para el cumplimiento de una obligación legal para la cual el responsable de los datos esté sujeto.

4. Que el tratamiento de los datos personales esté autorizado por una ley especial o las normativas que las desarrollan.

La persona que consienta dicho tratamiento debe ser debidamente informada respecto del propósito del uso de sus datos personales. El consentimiento podrá obtenerse de forma que permita su trazabilidad mediante documentación, ya sea electrónica o mediante cualquier otro mecanismo que resulte adecuado al medio de que se trate el caso y podrá ser revocado, sin efecto retroactivo.

### Artículo 7.

El responsable del tratamiento de datos personales contenidos en bases de datos establecerá los protocolos, procesos y procedimientos de gestión y transferencia segura, protegiendo los derechos de los titulares sobre sus datos bajo los preceptos de esta Ley.

Lo anterior será fiscalizado y supervisado por la Autoridad Nacional de Transparencia y Acceso a la Información, con el apoyo de la Autoridad Nacional para la Innovación Gubernamental, cuando se trate de aspectos relacionados a las Tecnologías de la Información y la Comunicación (TICs).

Los requerimientos mínimos que deben contener las políticas de privacidad, los protocolos, los procesos y los procedimientos de tratamiento y transferencia segura que deberá cumplir el responsable del tratamiento de datos serán emitidos por el regulador de cada sector bajo conforme a esta Ley.

### Artículo 8.

No se requiere autorización para el tratamiento de datos personales en los casos siguientes:

1. Los que provengan o que se recolecten de fuentes de dominio público o accesible en medios públicos.

2. Los que se recolecten dentro del ejercicio de las funciones propias de la Administración Pública en el ámbito de sus competencias.

3. Los de carácter económico, financiero, bancario o comercial que cuenten con el consentimiento previo.

4. Los que se contengan en listas relativas a una categoría de personas que se limiten a indicar antecedentes, como la pertenencia de la persona natural a una organización, su profesión o actividad, sus títulos educativos, dirección o fecha de nacimiento.

5. Los que son necesarios dentro de una relación comercial establecida, ya sea para la atención directa, comercialización o venta de los bienes o servicios pactados.

6. El tratamiento de datos personales que realicen organizaciones privadas para el uso exclusivo de sus asociados y de las entidades a que están afiliadas, con fines estadísticos, de tarificación u otros de beneficio general de aquellos.

7. Los casos de urgencia médica o sanitaria.

8. El tratamiento de información autorizado por la ley para fines históricos, estadísticos o científicos.

9. El tratamiento que sea necesario para la satisfacción de intereses legítimos perseguidos por el responsable del tratamiento o por un tercero, siempre que sobre dichos intereses no prevalezcan los intereses o los derechos y libertades fundamentales del interesado que requieran la protección de datos personales, en particular cuando el interesado sea un menor de edad o una persona con discapacidad.

Cuando el consentimiento se refiera a datos personales sensibles de salud, el consentimiento será previo, irrefutable y expreso.

En los supuestos previstos en el presente artículo, el titular de los datos podrá ejercer el derecho de acceso a sus datos personales sin cargo alguno. El titular podrá, en cualquier momento, solicitar la modificación, eliminación o bloqueo de sus datos personales de las bases de datos a los que se refiere este artículo. Lo anterior se entiende, sin perjuicio de lo que dispongan leyes especiales.

### Artículo 9.

Las personas que tengan acceso o estén involucradas en el tratamiento de datos personales, tanto en organismos públicos como privados, están obligadas a guardar confidencialidad sobre estos cuando provengan o hayan sido recolectados de fuentes que no sean de dominio o acceso al público, así como sobre los demás datos y antecedentes relacionados con la base de datos, obligación que no cesa por haber terminado sus actividades en ese ámbito.

### Artículo 10.

En caso de que el tratamiento de datos personales se efectúe por mandato, se aplicarán las reglas generales, en las cuales se dejará constancia, entre otros, que el consentimiento sea otorgado por escrito o de forma electrónica, siempre que exista certeza de su otorgamiento, estableciendo las condiciones para el tratamiento o la utilización de los datos personales. El mandatario deberá respetar esas estipulaciones en el cumplimiento de su encargo.

### Artículo 11.

Los datos personales deben utilizarse para los fines determinados, explícitos y lícitos para los cuales hubieran sido autorizados al momento de su recolección. Para cualquier otro uso que quiera darse a estos datos personales será necesario obtener el consentimiento del titular, que exista una ley especial que permita dicho tratamiento o que sea necesario para el cumplimiento de una obligación contractual, donde el propietario de los datos sea parte, así como cuando sea requerido por una entidad pública en el ejercicio de sus funciones legales o por orden judicial.

### Artículo 12.

En el caso de tratamiento posterior de los datos con fines de investigación, estudios o encuestas o conocimientos de interés público, no será necesario el consentimiento del titular de los datos, siempre que estos sean anonimizados por el responsable de su custodia o tratamiento. La comunicación de sus resultados debe omitir las señas que puedan permitir la identificación de las personas consultadas.

### Artículo 13.

Los datos sensibles no pueden ser objeto de transferencia, excepto en los casos siguientes:

1. Cuando el titular haya dado su autorización explícita, salvo en los casos que por ley no sea requerido el otorgamiento de dicha autorización.

2. Cuando sea necesario para salvaguardar la vida del titular y este se encuentre física o jurídicamente incapacitado. En estos casos, los acudientes, curadores o quienes tengan la tutela deben dar la autorización.

3. Cuando se refiera a datos que sean necesarios para el reconocimiento, ejercicio o defensa de un derecho en un proceso con autorización judicial competente.

4. Cuando tenga una finalidad histórica, estadística o científica. En este caso, deberán adoptarse las medidas conducentes a disociar la identidad de los titulares.

### Artículo 14.

El custodio de la base de datos regulado por esta Ley, por encargo o mandato del responsable del tratamiento de los datos personales, así como todo aquel que tenga acceso a los datos personales por razón de su relación a nivel jerárquico, deberá cuidar de estos con la debida diligencia, ya que será igualmente responsable por aquellos daños o perjuicios ocasionados que le sean exigibles.

## Capítulo II — Derechos de los Titulares de Datos Personales

### Artículo 15.

Se reconocen como derechos irrenunciables básicos los derechos que tienen los titulares de datos personales, sin perjuicio de cualquier otro derecho reconocido en esta Ley:

1. Derecho de acceso: permite al titular obtener sus datos personales que se encuentren almacenados o sujetos a tratamiento en bases de datos de instituciones públicas o privadas, además de conocer el origen y la finalidad para los cuales han sido recabados.

2. Derecho de rectificación: permite al titular solicitar la corrección de sus datos personales que sean incorrectos, irrelevantes, incompletos, desfasados, inexactos, falsos o impertinentes.

3. Derecho de cancelación: permite al titular solicitar la eliminación de sus datos personales incorrectos, irrelevantes, incompletos, desfasados, inexactos, falsos o impertinentes.

4. Derecho de oposición: permite al titular, por motivos fundados y legítimos relacionados con una situación en particular, negarse a proporcionar sus datos personales o a que sean objeto de determinado tratamiento, así como a revocar su consentimiento.

5. Derecho de portabilidad: derecho a obtener una copia de los datos personales de manera estructurada, en un formato genérico y de uso común, que permita ser operado por distintos sistemas y/o transmitirlos a otro responsable, cuando:

a. El titular haya entregado sus datos directamente al responsable.

b. Sea un volumen relevante de datos, tratados de forma automatizada.

c. El titular haya dado su consentimiento para el tratamiento o se requiera para la ejecución o el cumplimiento de un contrato.

En todo momento, el titular de los datos personales podrá ejercer estos derechos, los cuales son irrenunciables, salvo las excepciones establecidas en leyes especiales.

### Artículo 16.

El titular de datos personales o quien lo represente podrá solicitar su información a los responsables del tratamiento de datos, la cual deberá ser proporcionada en un plazo no mayor de diez días hábiles, a partir de la fecha de presentación de dicha solicitud.

Sin perjuicio de las excepciones legales, el titular tendrá, además, derecho a exigir que se eliminen sus datos personales cuando su almacenamiento carezca de fundamento legal, cuando no hayan sido expresamente autorizados o cuando estuvieran caducos.

El suministro de información, la modificación, bloqueo o la eliminación de los datos personales será absolutamente gratuito y deberá proporcionarse, a solicitud del titular de los datos o quien lo represente, constancia de la base de datos actualizada en lo concerniente.

### Artículo 17.

Los datos deberán ser modificados cuando sean erróneos, inexactos, equívocos o incompletos dentro de un término de cinco días hábiles siguientes a la solicitud de modificación, quien sea responsable de una base de datos regulada por esta Ley, podrá proceder a la eliminación, modificación o bloqueo de los datos personales sin necesidad de requerimientos del titular, cuando existan pruebas de inexactitud de dichos datos.

Se bloquearán los datos personales cuya exactitud no pueda ser establecida o cuya vigencia sea dudosa y respecto de los cuales no corresponda la cancelación. En este caso, serán bloqueados para acceso a terceros o para evitar su uso en otros fines que no hayan sido los expresamente autorizados.

En todo caso, corresponderá a la Autoridad Nacional de Transparencia y Acceso a la Información, como autoridad competente, determinar cuándo un dato es inexacto o cuándo carece de fundamento legal, sin perjuicio de lo dispuesto en leyes especiales que regulen materias específicas.

### Artículo 18.

Si el responsable de la base de datos personales no se pronuncia sobre la solicitud del titular de datos personales dentro de los términos establecidos, el titular de los datos personales tendrá derecho a recurrir a la Autoridad Nacional de Transparencia y Acceso a la Información. En caso de sujetos regulados por leyes especiales, el ciudadano deberá acudir a la autoridad reguladora y, a falta de respuesta de esta, deberá recurrir a la Autoridad Nacional de Transparencia y Acceso a la Información.

La Autoridad Nacional de Transparencia y Acceso a la Información está facultada para solicitar la información necesaria y efectuar verificaciones a fin de realizar las investigaciones administrativas relacionadas exclusivamente y en cada caso con la queja o denuncia presentada.

### Artículo 19.

El titular de los datos personales tiene derecho a no ser sujeto de una decisión basada únicamente en el tratamiento automatizado de sus datos personales, que produzca efectos jurídicos negativos o le produzca un detrimento a un derecho, cuyo objeto sea evaluar determinados aspectos de su personalidad, estado de salud, rendimiento laboral, crédito, fiabilidad, conducta, características o personalidad, entre otros.

No obstante, dicha decisión será posible cuando:

1. El titular de los datos personales la haya consentido.

2. Sea necesaria para celebrar o dar cumplimiento a un contrato o relación jurídica entre el responsable del tratamiento y el titular de los datos personales.

3. Sea autorizada por leyes especiales o las normativas que las desarrollen.

### Artículo 20.

Los establecimientos de salud públicos o privados y los profesionales de la medicina pueden recolectar y procesar los datos personales relativos a la salud física o mental de los titulares que como pacientes acudan a estos o que estén o hubieran estado bajo su tratamiento, respetando los principios del secreto profesional y lo establecido en la presente Ley o en leyes especiales que regulan dicha materia.

### Artículo 21.

El derecho del titular de los datos personales al acceso, revocación, cancelación, oposición o bloqueo de sus datos no puede ser limitado mediante ningún acto o convenio entre partes, en cuyo caso se declarará nulo el acto de limitación.

### Artículo 22.

Si los datos personales se encuentran almacenados en una base de datos que se alimente de datos provistos por diversos organismos, el titular podrá requerir información a cualquiera de los responsables de datos que suministran la información.

### Artículo 23.

No podrá solicitarse información, rectificación, cancelación o bloqueo de datos personales cuando ello impida o entorpezca el debido trámite dentro de un proceso administrativo o judicial o por seguridad del Estado.

Tampoco podrá pedirse la rectificación, cancelación o bloqueo de datos personales almacenados por mandato legal fuera de los casos establecidos en leyes especiales que les aplique.

### Artículo 24.

Los responsables o custodios de bases de datos deberán entregar a las autoridades judiciales competentes la información relacionada al almacenamiento o transferencia de datos personales que sea debidamente solicitada para el aseguramiento del cumplimiento de la ley.

En cualquier caso, la solicitud tendrá que estar debidamente proporcionada, no admitiéndose en ningún caso solicitudes masivas de información sobre datos personales.

En todo caso, dicha solicitud deberá ir dirigida al responsable del tratamiento o al titular de los datos, que es el único que puede responderla, ordenando en su caso al responsable del tratamiento o quien lo tuviera por mandato o encargo de dicho responsable que entregue los datos a la autoridad judicial competente.

## Capítulo III — Utilización de Datos Personales

### Artículo 25.

Los responsables del tratamiento de datos solo podrán transferir información sobre estos cuando cuenten con el consentimiento previo, informado e inequívoco del titular, salvo las excepciones establecidas en esta Ley o en las leyes especiales.

### Artículo 26.

Los operadores que gestionen redes públicas o que presten servicios de comunicación disponibles al público deberán garantizar en el ejercicio de su actividad la protección de los datos personales conforme a esta Ley y la normativa que la desarrolle.

Asimismo, deberán adoptar las medidas técnicas y de gestión adecuada para preservar la seguridad en la explotación de la red o en la prestación de los servicios, con el fin de garantizar los niveles de protección de los datos personales que sean exigidos mediante esta Ley y su reglamentación, así como las certificaciones, protocolos, estándares y otras medidas que establezcan las autoridades respectivas.

En caso de que exista una afectación particular de violación de la seguridad de la red pública de comunicaciones, el operador que gestione dicha red o preste el servicio de comunicaciones informará a los titulares sobre dicha afectación y sobre las medidas a adoptar. La regulación dispuesta en esta Ley se entiende sin perjuicio de lo previsto en las normas especiales sobre telecomunicaciones, relacionadas con la seguridad pública y la defensa nacional.

### Artículo 27.

En caso de que la recolección de la información se realice a través de Internet u otro medio de comunicación digital, las obligaciones establecidas en esta Ley se completarán mediante la presentación al interesado de las políticas de privacidad y/o condiciones de servicios accesibles.

En todo caso, si el consentimiento del titular se da en el contexto de una declaración escrita que también se refiera a otros asuntos, la solicitud de consentimiento se presentará de tal forma que se distinga claramente de los demás, de forma comprensible y de fácil acceso, utilizando un lenguaje claro y sencillo, que no será vinculante en ninguna parte de la declaración que constituya infracción de esta Ley y su reglamentación.

### Artículo 28.

En ningún caso el responsable del tratamiento de datos personales y/o el custodio de la base de datos pueden transferir o comunicar los datos que se relacionen con una persona identificada o identificable, después de transcurridos siete años desde que se extinguió la obligación legal de conservarla, salvo que el titular de los datos personales expresamente solicite lo contrario.

### Artículo 29.

El tratamiento de datos personales por parte de una entidad pública, solo podrá efectuarse respecto de las materias de su competencia y con sujeción a lo establecido en esta Ley.

### Artículo 30.

Las entidades públicas que sometan a tratamiento datos personales relativos a condenas por delitos, infracciones administrativas o faltas disciplinarias no podrán comunicarlos, una vez prescrita la acción penal o administrativa o cumplida o prescrita la sanción o la pena, salvo autorización expresa por el titular del dato.

Se exceptúan los casos en que esa información les sea solicitada por los tribunales de justicia competentes u otros organismos públicos dentro del ámbito de su competencia, que deberán guardar respecto de ella la debida reserva o confidencialidad y les será aplicable lo dispuesto en los artículos 11 y 20.

### Artículo 31.

Los responsables y/o custodios de bases de datos que transfieran datos personales almacenados en bases de datos a terceros llevarán un registro de estas y deberán estar a disposición de la Autoridad Nacional de Transparencia y Acceso a la Información en caso de que esta lo requiera para cumplir con las facultades que le otorga esta Ley.

En el registro al que se refiere el párrafo anterior constará, respecto de cada una de esas bases de datos, la identificación de estas y el responsable de estas, la naturaleza de los datos personales que contiene, el fundamento jurídico de su existencia, los procedimientos de obtención y tratamiento de los datos, el destino de los datos y las personas naturales o jurídicas a las que pueden ser transferidos, la descripción del universo de personas que comprende, las medidas de seguridad, los protocolos y la descripción técnica de la base de datos, la forma y condiciones en que las personas pueden recibir o acceder a los datos referidos a ellas, los procedimientos a realizar para la rectificación, la actualización de los datos, el tiempo de conservación de los datos y cualquier cambio de los elementos indicados, así como la identificación y periodo de todas las personas que han ingresado a los datos personales dentro de los quince días hábiles desde que se inicie dicha actividad.

Solo pueden ser capturados para almacenamiento los datos obtenidos del documento de identidad personal que provea su titular.

### Artículo 32.

En una solicitud de transferencia de datos personales, mediante el uso de una red digital o de cualquier otro medio, deberá dejarse constancia de:

1. La individualización del requirente.

2. El motivo y el propósito del requerimiento.

3. Los datos que se requiere que sean trasferidos.

4. La notificación a los titulares de los datos personales que integran el requerimiento, el motivo y el nuevo responsable de la información, salvo consentimiento previo por parte del titular.

5. El tiempo máximo que el requirente utilizará los datos y la forma como serán destruidos una vez terminado su uso.

Se exceptúan de estos requerimientos los procesos internos del responsable del tratamiento de los datos.

### Artículo 33.

Se entenderá que toda transferencia de datos personales es lícita si se cumple al menos una de las condiciones siguientes:

1. Que cuente con el consentimiento del titular de los datos.

2. Que el país u organismo internacional o supranacional receptor proporcione un nivel de protección equivalente o superior.

3. Que se encuentre prevista en una ley o tratado en los que la República de Panamá sea parte.

4. Que sea necesaria para la prevención o el diagnóstico médico, la prestación de asistencia sanitaria, tratamiento médico o la gestión de servicios sanitarios.

5. Que sea efectuada a cualquier sociedad del mismo grupo económico del responsable del tratamiento, siempre que los datos personales no sean utilizados para finalidades distintas las que originaron su recolección.

6. Que sea necesaria en virtud de un contrato celebrado o por celebrar en interés inequívoco del titular de los datos, por el responsable del tratamiento y un tercero.

7. Que sea necesaria o legalmente exigida para la salvaguarda de un interés público o para la representación legal del titular de los datos personales o administración de justicia.

8. Que sea necesaria para el reconocimiento, ejercicio o defensa de un derecho en un proceso judicial, o en casos de colaboración judicial internacional.

9. Que sea necesaria para el mantenimiento o cumplimiento de una relación jurídica entre el responsable del tratamiento y el titular de los datos.

10. Que sea requerida para concretar transferencias bancarias o bursátiles, en lo relativo a las transacciones respectivas y conforme la legislación que les resulte aplicable.

11. Que tenga por objeto la cooperación internacional entre organismos de inteligencia para la lucha contra el crimen organizado, el terrorismo, el lavado de activos, los delitos informáticos, la pornografía infantil y el narcotráfico.

12. Que el responsable del tratamiento que transfiere los datos y el destinatario adopten mecanismos de autorregulación vinculante, siempre que estos sean acordes a las disposiciones previstas en esta Ley.

13. Que se realice en el marco de cláusulas contractuales que contengan mecanismos de protección de los datos personales acordes con las disposiciones previstas en la presente Ley, siempre que el titular sea parte.

En todos los casos, el responsable del tratamiento que transfiere los datos y el receptor de los datos personales serán responsables por la licitud del tratamiento de los datos transferidos.

## Capítulo IV — Consejo de Protección de Datos Personales

### Artículo 34.

Se crea el Consejo de Protección de Datos Personales como ente consultivo en la materia que regula la presente Ley, que estará conformado por:

1. El ministro de Comercio e Industrias o quien este delegue, quien la presidirá.

2. El administrador general de la Autoridad de Protección al Consumidor y Defensa de la Competencia o quien este delegue.

3. El director general de Autoridad Nacional de Transparencia y Acceso a la Información o quien este delegue, quien ejercerá la Secretaría de esta.

4. El defensor del pueblo o quien este delegue.

5. Un representante del Consejo Nacional de la Empresa Privada.

6. Un representante del Colegio Nacional de Abogados.

7. Un representante de la Asociación Bancaria de Panamá.

8. Un representante del Tribunal Electoral.

9. Un representante de la Cámara de Comercio, Industrias y Agricultura de Panamá.

Los representantes del Consejo Nacional de la Empresa Privada, del Colegio Nacional de Abogados, la Asociación Bancaria de Panamá y la Cámara de Comercio, Industrias y Agricultura de Panamá, así como sus respectivos suplentes, serán designados por su Junta Directiva por un periodo de dos años.

El administrador general de la Autoridad Nacional para la Innovación Gubernamental o quien este delegue, participará en las reuniones del Consejo de Protección de Datos Personales como asesor técnico y tendrá derecho a voz.

### Artículo 35.

El Consejo de Protección de Datos Personales tendrá las facultades siguientes:

1. Asesorar a la Autoridad Nacional de Transparencia y Acceso a la Información en materia de protección de datos personales, recomendar acciones y reglamentos.

2. Recomendar políticas públicas relacionadas con esta materia.

3. Evaluar casos que le sean presentados para consulta y brindar sus recomendaciones.

4. Desarrollar su reglamento interno.

## Capítulo V — Responsabilidad por las Infracciones

### Artículo 36.

La Autoridad Nacional de Transparencia y Acceso a la Información, a través de la Dirección creada para conocer esta materia, está facultada para sancionar a la persona natural o jurídica responsable del tratamiento de los datos personales, así como al custodio de la base de datos, que por razón de la investigación de las quejas o denuncias que se les presenten y se les compruebe que han infringido los derechos del titular de los datos personales.

Las decisiones de la Dirección competente para esta materia dentro de la Autoridad Nacional de Transparencia y Acceso a la Información serán impugnables mediante recurso de reconsideración ante esta Dirección y de apelación que se interpondrá ante el director general de la Autoridad Nacional de Transparencia y Acceso a la Información como segunda instancia, los cuales se sustentarán en un término de cinco días, a partir del día siguiente hábil después de su notificación.

Aquellos casos de queja que se presenten ante los entes reguladores, en los que se realicen tratamientos de datos que se encuentren regulados por leyes especiales y que no se encuentren las sanciones a las faltas cometidas en dichas leyes expresamente tipificadas, el regulador a quien se le interponga la queja deberá aplicar supletoriamente las sanciones establecidas en esta Ley.

La Autoridad Nacional de Transparencia y Acceso a la Información fijará los montos de las sanciones aplicables a las respectivas faltas, acordes a la gravedad de las faltas, que se establecerán desde mil balboas (B/.1 000.00) hasta diez mil balboas (B/.10 000.00), así como reglamentará el procedimiento correspondiente.

Las sanciones pecuniarias que imponga la Autoridad Nacional de Transparencia y Acceso a la Información en el ejercicio de las facultades establecidas en esta Ley que no hayan sido pagadas en el término concedido, se remitirán para su cobro a la Dirección General de Ingresos del Ministerio de Economía y Finanzas.

### Artículo 37.

El responsable del tratamiento de los datos personales deberá indemnizar el daño patrimonial y/o moral que causará por el tratamiento indebido de estos, de conformidad con lo establecido en esta Ley o en el ordenamiento legal vigente.

Los tribunales de justicia conocerán de las demandas que se presenten contra los responsables del tratamiento de los datos personales, así como sobre las reclamaciones por daños y perjuicios causados.

## Capítulo VI — Infracciones y Sanciones

### Artículo 38.

Las infracciones a esta Ley se califican en leves, graves o muy graves.

### Artículo 39.

Se considera infracción leve:

1. No remitir y/o informar a la Autoridad Nacional de Transparencia y Acceso a la Información dentro de los plazos requeridos la información de lo ordenado en esta Ley, su reglamentación o cualquier otra disposición normativa.

### Artículo 40.

Se consideran infracciones graves:

1. Efectuar el tratamiento de datos personales sin haber obtenido el consentimiento de su titular, según el procedimiento indicado por esta Ley, su reglamentación o cualquier otra disposición normativa que se refiera a la presente Ley.

2. Infringir los principios y garantías establecidos en la presente Ley o en su reglamentación.

3. Infringir el compromiso de confidencialidad relacionado al tratamiento de los datos personales.

4. Restringir o entorpecer la aplicación de los derechos de acceso, rectificación, cancelación y oposición.

5. Incumplir el deber de informar al titular afectado acerca del tratamiento de sus datos personales, cuando los datos no hayan sido obtenidos del propio titular.

6. Almacenar o archivar datos personales sin contar con las adecuadas condiciones de seguridad que esta Ley o su reglamento disponga.

7. No atender la reiteración de los requerimientos u observaciones formalmente notificados, o no proporcionar la documentación o información formalmente solicitada por la Autoridad Nacional de Transparencia y Acceso a la Información.

8. Entorpecer o no cooperar con la Autoridad Nacional de Transparencia y Acceso a la Información al momento en que esta ejerza su función de inspección.

### Artículo 41.

Se consideran infracciones muy graves:

1. Recopilar de datos personales en forma dolosa.

2. No observar de las regulaciones establecidas respecto al tratamiento de los datos sensibles.

3. No suspender el tratamiento de datos personales cuando existiera un previo requerimiento de la Autoridad Nacional de Transparencia y Acceso a la Información para ello.

4. Almacenar o transferir internacionalmente datos personales, violentando lo establecido en esta Ley.

5. Reincidir en las faltas graves.

### Artículo 42.

Las sanciones que imponga la Autoridad Nacional de Transparencia y Acceso a la Información a los responsables de las bases de datos y demás sujetos alcanzados por el régimen de la presente Ley y sus reglamentos, se graduarán dependiendo de la gravedad de la infracción cometida.

### Artículo 43.

Las infracciones a esta Ley serán sancionadas así:

1. Falta leve, citación ante la Autoridad Nacional de Transparencia y Acceso a la Información con relación a registros o atender faltas.

2. Faltas graves, multas según su proporcionalidad.

3. Faltas muy graves:

a. Clausura de los registros de la base de datos, sin perjuicio de la multa correspondiente. Para ejecutar esta acción, la Autoridad Nacional de Transparencia y Acceso a la Información deberá contar con la opinión formal del Consejo de Protección de Datos Personales, sin perjuicio de los recursos que esta Ley le concede al afectado.

b. Suspensión e inhabilitación de la actividad de almacenamiento y/o tratamiento de datos personales de forma temporal o permanente, sin perjuicio de la multa correspondiente.

Se considerará reincidencia cuando la misma falta se repita dentro de un periodo de tres años.

Para hacer cumplir la sanción de suspensión o clausura, la Autoridad Nacional de Transparencia y Acceso a la Información podrá requerir el auxilio de la Fuerza Pública.

Los hechos que acarreen una sanción serán documentados de acuerdo con las formalidades legales y se realizarán informes estadísticos que permitan a la Autoridad Nacional de Transparencia y Acceso a la Información establecer la gravedad, reiteración o reincidencia de la infracción cometida.

## Capítulo VII — Disposiciones Finales

### Artículo 44.

Los titulares de los datos personales registrados en bases de datos creados con anterioridad a la entrada en vigencia de la presente Ley tendrán los derechos que esta les confiere.

### Artículo 45.

La Autoridad Nacional de Transparencia y Acceso a la Información contará con los recursos presupuestarios y financieros para el debido cumplimiento de las funciones que se le atribuyen mediante esta Ley, los cuales le serán asignados de conformidad con las normas vigentes en materia presupuestaria, destinados para el debido funcionamiento de la Dirección creada para la ejecución de esta Ley, dentro de la estructura organizativa de la Autoridad Nacional de Transparencia y Acceso a la Información.

### Artículo 46.

El Órgano Ejecutivo reglamentará la presente Ley en coordinación con Autoridad Nacional de Transparencia y Acceso a la Información.

### Artículo 47.

Esta Ley comenzará a regir a los dos años de su promulgación.

COMUNÍQUESE Y CÚMPLASE.

Proyecto 665 de 2018 aprobado en tercer debate en el Palacio Justo Arosemena, ciudad de Panamá, a los veinticuatro días del mes de octubre del año dos mil dieciocho.

La Presidenta, Yanibel Ábrego S.

El Secretario General, Franz O. Wever Z.

ÓRGANO EJECUTIVO NACIONAL. PRESIDENCIA DE LA REPÚBLICA

PANAMÁ, REPÚBLICA DE PANAMÁ, 26 DE MARZO DE 2019.

JUAN CARLOS VARELA R.

Presidente de la República

JORGE LUIS GONZÁLEZ

Ministro de la Presidencia
